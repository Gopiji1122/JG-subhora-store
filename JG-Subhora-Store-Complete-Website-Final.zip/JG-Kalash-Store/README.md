# JG Kalash Store - Static Website

Responsive GitHub Pages store catalogue with five categories, nine product pages, cart, WhatsApp order enquiry, persistent browser cart, product search, dark/light mode, mobile category menu, SEO metadata, sitemap, robots.txt and custom 404 page.

## Before public launch
1. The brand heading is currently **JG Kalash Store**. The canonical domain is configured as `https://subhora.in/` based on the chosen domain; change it if the final registered domain differs.
2. Update real product names, prices and product details in `assets/js/products.js` and each product page. `price: null` is intentional until actual prices are supplied. Do not publish guessed prices.
3. Add final product photos under `assets/images/products/` and update image paths in `assets/js/products.js` and product pages. The starter Thali image is preserved under `assets/images/categories/`.
4. WhatsApp contact is configured as +91 92162 89916 (`919216289916`). Verify that this number has WhatsApp enabled before publishing.
5. Complete and verify Shipping & Returns, Privacy Policy and Terms & Conditions against your actual business process. Current copy is starter guidance, not legal advice.
6. For GitHub Pages, configure the repository and custom domain `subhora.in` in repository settings, then enable HTTPS. Canonical URLs and sitemap currently use the custom domain.
7. GitHub Pages is static hosting. The cart is stored in the visitor's browser; it does not reserve inventory or automatically create a server-side order. WhatsApp opens a prefilled message that the customer must send.
8. Search and cart pages are marked `noindex`; product and category pages are intended for indexing.

## Product prices
Edit each product's `price` value in `assets/js/products.js` from `null` to the actual numeric price. Example: `"price": 499`. The displayed prices, cart subtotal and WhatsApp order message will then use that value. Keep product page JSON-LD in sync with final verified details.

## Preview
Extract the ZIP and open `index.html` in a browser. For best testing, use a local static server because browser storage and path behaviour can vary when opening files directly.
